package com.josephsullivan256.gmail.gl.input;

public interface MouseDXCallback {
	public void invoke(float dx, float dy);
}

package com.josephsullivan256.gmail.core;

public class Level3DV2 {
	private boolean[][][] level;
	private int x1,y1,z1;
	
	public Level3DV2(int x1, int y1, int z1, int iterations){
		level = new boolean[x1][y1][z1];
		this.x1 = x1;
		this.y1 = y1;
		this.z1 = z1;
		
		generateWalls();
	}
	
	private void generateWalls(){
		for(int x = 0; x < x1; x++){
			for(int y = 0; y < y1; y++){
				for(int z = 0; z < z1; z++){
					if(!(x>0 && x<x1-1 && y>0 && y<y1-1 && z>0 && z<z1-1)){
						level[x][y][z] = true;
					}
				}
			}
		}
	}
	
	public boolean[][][] getLevel(){
		return level;
	}
}

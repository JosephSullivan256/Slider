package com.josephsullivan256.gmail.math.linalg;

public interface MatrixBuilder {
	public float calculate(int r, int c);
}
